# Structure Patterns

```plaintext
repository-name/
├── src/
│   ├── {ProjectName}.Domain/
│   │   ├── Common/
│   │   ├── Exceptions/
│   │   ├── Models/
│   │   └── Utils/
│   │
│   ├── {ProjectName}.Application/
│   │   ├── Common/
│   │   │   ├── Behaviors/
│   │   │   ├── Interfaces/
│   │   │   └── Options/
│   │   ├── Features/
│   │   │   ├── {FeatureA}/
│   │   │   │   ├── Commands/
│   │   │   │   │   └── {CommandName}/
│   │   │   │   │       ├── {CommandName}Command.cs
│   │   │   │   │       ├── {CommandName}CommandHandler.cs
│   │   │   │   │       └── {CommandName}CommandValidator.cs
│   │   │   │   ├── Queries/
│   │   │   │   │   └── {QueryName}/
│   │   │   │   │       ├── {QueryName}Query.cs
│   │   │   │   │       ├── {QueryName}QueryHandler.cs
│   │   │   │   │       └── {QueryName}QueryValidator.cs
│   │   │   │   └── Dtos/
│   │   │   └── {FeatureB}/
│   │   └── Utils/
│   │
│   ├── {ProjectName}.Infrastructure/
│   │   ├── Caches/
│   │   ├── Files/
│   │   ├── Services/
│   │   │   └── HangfireJobService/
│   │   ├── Persistence/
│   │   │   ├── Configurations/
│   │   │   └── Repositories/
│   │   ├── Migrations/
│   │   │   └── DBScripts/
│   │   └── DependencyInjection.cs
│   │
│   └── {ProjectName}.WebApi/
│       ├── Endpoints/
│       ├── Extensions/
│       └── Middleware/
│
├── tests/
│   ├── {ProjectName}.Domain.Tests/
│   ├── {ProjectName}.Application.Tests/
│   └── {ProjectName}.IntegrationTests/
│
├── .gitignore
├── docker-compose.yml
├── {ProjectName}.slnx
└── README.md
```
